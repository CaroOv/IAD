
################################
############### backdrop pallete
from mbort import backdrop_palette
backdrop_palette.backdrop.start()


import stamps

import concatenate2Dtransforms

import align



nuke.menu('Nuke').addCommand('Scripts/align', 'align.aligner()') 
nuke.menu('Nuke').addCommand('Scripts/concatenate', 'transformstoMatrix()') 


##---------- Ym_alignNodes ----------

import  Ym_alignNodes

toolbar = nuke.toolbar('Nodes')
mcMenu = toolbar.addMenu('Ym_alignNodes Ver1.5', icon='alignNodes.png')

mcMenu.addCommand('Left X', 'Ym_alignNodes.alignLX()', '+F1',icon='leftX.png')
mcMenu.addCommand('Center X', 'Ym_alignNodes.alignCX()', '+F2',icon='centerX.png')
mcMenu.addCommand('Right X', 'Ym_alignNodes.alignRX()', '+F3',icon='rightX.png')
mcMenu.addCommand('Interval X', 'Ym_alignNodes.align_intX()', '+F4',icon='intervalX.png')

mcMenu.addCommand('Top Y', 'Ym_alignNodes.alignTY()', '+F5',icon='topY.png')
mcMenu.addCommand('Center Y', 'Ym_alignNodes.alignCY()', '+F6',icon='centerY.png')
mcMenu.addCommand('Under Y', 'Ym_alignNodes.alignUY()', '+F7',icon='underY.png')
mcMenu.addCommand('Interval Y', 'Ym_alignNodes.align_intY()', '+F8',icon='intervalY.png')

mcMenu.addCommand('Interval XX', 'Ym_alignNodes.align_intXX()', '+F9',icon='intervalXX.png')
mcMenu.addCommand('Interval YY', 'Ym_alignNodes.align_intYY()', '+F10',icon='intervalYY.png')

import os
import nukescripts
    

nodesToolbar = nuke.toolbar('Nodes')


#create backdrop / launch panel on use alt b hotkey in DAG 
   # tb=toolbar.menu('Other')
mcMenu.addCommand('Backdrop','createBackDropPanel()', 'Alt+b')




#################################################################################################
#                                           dotToConnect                                        #
#################################################################################################

import nuke

def dDotParent():

    parentName = nuke.getInput('ParentName','')
    parentKnob = nuke.Text_Knob('parent', 'parent')

    if parentName == None:
        return False

    if parentName == '':
        nuke.message('No parent name given.')
        return False

    if nuke.Root().selectedNode() == None:
        nuke.message('Error:Nothing is selected.')

    elif len(nuke.selectedNodes()) > 1:
        nuke.message('Error:Multiple nodes selected')

    elif nuke.selectedNode().Class() == 'Dot':
        if nuke.selectedNode().knob('child'):
            nuke.message("Error:It's a child.")
        else:
                nuke.selectedNode().knob('label').setValue('[value name]')
                nuke.selectedNode().knob('name').setValue(parentName)
                nuke.selectedNode().knob('tile_color').setValue(0)
                nuke.selectedNode().knob('note_font_size').setValue(33)
                if nuke.selectedNode().knob('parent'):
                    pass
                else:
                    nuke.selectedNode().addKnob(parentKnob)

    else:
        newDot = nuke.createNode('Dot')
        newDot.knob('label').setValue('[value name]')
        newDot.knob('name').setValue(parentName)
        newDot.knob('tile_color').setValue(0)
        newDot.knob('note_font_size').setValue(33)
        newDot.addKnob(parentKnob)

def dDotConnect():
    dotList = []
    for node in nuke.allNodes('Dot'):
        if node.knob('parent'):
            dotList.append(node.name())

    dotList.sort()
    p = nuke.Panel('Parent Dot List')
    p.addEnumerationPulldown('Parent',' '.join(dotList))
    ret = p.show()
    if p.value('Parent') != None:
        selectedParent = p.value('Parent')
    else:
        return False
    parent = nuke.toNode(selectedParent)
    selectedNodes = nuke.selectedNodes()
    childKnob = nuke.Text_Knob('child', 'child')

    if len( selectedNodes ) !=0:
        for n in selectedNodes:
            if  n.knob('parent'):
                pass
            elif n.Class() != 'Dot':
                pass
            else:
                n.connectInput(0, parent)
                n.knob('label').setValue(selectedParent)
                n.knob('tile_color').setValue(0)
                n.knob('hide_input').setValue(True)
                n.knob('note_font').setValue('italic')
                n.knob('note_font_size').setValue(33)
                parentColor = n.input(0).knob('note_font_color').getValue()
                parentColor = int(parentColor)
                n.knob('note_font_color').setValue(parentColor)
                childKnob = nuke.Text_Knob('child', 'child')
                if n.knob('child'):
                    pass
                elif n.knob('parent'):
                    pass
                elif n.Class() != 'Dot':
                    pass
                else:
                    n.addKnob(childKnob)
    else:
        nuke.createNode("Dot").connectInput(0, parent)
        nuke.selectedNode().knob('label').setValue(selectedParent)
        nuke.selectedNode().knob('tile_color').setValue(0)
        nuke.selectedNode().knob('hide_input').setValue(True)
        nuke.selectedNode().knob('note_font').setValue('italic')
        nuke.selectedNode().knob('note_font_size').setValue(33)
        nuke.selectedNode().addKnob(childKnob)
        parentColor = nuke.selectedNode().input(0).knob('note_font_color').getValue()
        parentColor = int(parentColor)
        nuke.selectedNode().knob('note_font_color').setValue(parentColor)

def dDotConnectSelected():
    selectedNodes = nuke.selectedNodes()
    parent = selectedNodes[0]
    children = selectedNodes[1:]
    parentName = selectedNodes[0]['name'].getValue()

    for n in children:
        if  n.knob('parent'):
            pass
        elif n.Class() != 'Dot':
            pass
        else:
            n.connectInput(0, parent)
            n.knob('label').setValue(parentName)
            n.knob('tile_color').setValue(0)
            n.knob('hide_input').setValue(True)
            n.knob('note_font').setValue('italic')
            n.knob('note_font_size').setValue(33)
            parentColor = n.input(0).knob('note_font_color').getValue()
            parentColor = int(parentColor)
            n.knob('note_font_color').setValue(parentColor)
        if n.knob('child'):
            pass
        elif n.knob('parent'):
            pass
        elif n.Class() != 'Dot':
            pass
        else:
            childKnob = nuke.Text_Knob('child', 'child')
            n.addKnob(childKnob)

def dDotCheckInput():
    brokenConnections = []
    for d in nuke.allNodes('Dot'):
        if d.input(0) == None:
            d['tile_color'].setValue(4278190335)
            brokenConnections.append(d.knob('name').getValue())
        else:
            if d.knob('child'):
                childLabel = d.knob('label').getValue()
                parentName = d.input(0).knob('name').getValue()
                if childLabel == parentName:
                    d['tile_color'].setValue(0)
                else:
                    d['tile_color'].setValue(4278190335)
                    brokenConnections.append(d.knob('name').getValue())
            else:
                d['tile_color'].setValue(0)
    if len(brokenConnections) > 0:
        brokenConnections.sort()
        nuke.message('%s connection(s) broken: \n %s' % (len(brokenConnections), brokenConnections))

def dDotAutoConnect():

    for d in nuke.selectedNodes('Dot'):
        if d.knob('child'):
            childLabel = d.knob('label').getValue()
            parent = nuke.toNode(childLabel)
            try:
                parentColor = parent.knob('note_font_color').getValue()
                parentColor = int(parentColor)
            except:
                parentColor = 4278190335
            if d.input(0) == None:
                d.connectInput(0, parent)
                d['tile_color'].setValue(0)
                d.knob('note_font_size').setValue(33)
                d.knob('note_font_color').setValue(parentColor)
            else:
                parentName = d.input(0).knob('name').getValue()
                if childLabel != parentName:
                    d.connectInput(0, parent)
                    d['tile_color'].setValue(0)
                    d.knob('note_font_size').setValue(33)
                    d.knob('note_font_color').setValue(parentColor)
    dDotCheckInput()

def dDotShowChildren():

    selectedNode = nuke.selectedNode()
    dependentNodes = selectedNode.dependent()
    selectedNode.setSelected(False)
    for depnd in dependentNodes:
        depnd.setSelected(True)

def dDotToggleConnectionsVisibility():
    selectedNode = nuke.selectedNode()
    dependentNodes = selectedNode.dependent()
    for depnd in dependentNodes:
        currentState = depnd.knob('hide_input').getValue()
        depnd.knob('hide_input').setValue(not currentState)

def dDotRollDownNameChange():
     selectedNode = nuke.selectedNode()
     selectedNodeName = selectedNode.knob('name').getValue()
     parentColor = selectedNode.knob('note_font_color').getValue()
     parentColor = int(parentColor)
     if selectedNode.Class() == 'Dot':
        if selectedNode.knob('parent'):
            dependentNodes = selectedNode.dependent()
            for depnd in dependentNodes:
                if depnd.knob('child'):
                    depnd.knob('label').setValue(selectedNodeName)
                    depnd.knob('note_font_color').setValue(parentColor)
            dDotCheckInput()

def dDotGrabParentName():
    for n in nuke.selectedNodes('Dot'):
        if n.knob('child'):
            parentName = n.input(0).knob('name').getValue()
            parentNameNoNumbers = filter(lambda x: x.isalpha(), parentName)
            parentColor = n.input(0).knob('note_font_color').getValue()
            parentColor = int(parentColor)
            childName = n.knob('label').getValue()
            childNameNoNumbers = filter(lambda x: x.isalpha(), childName)
            if childNameNoNumbers.startswith(parentNameNoNumbers):
                n.knob('label').setValue(parentName)
                n.knob('note_font_color').setValue(parentColor)

    dDotCheckInput()

def dDotSelectChildren():
    childName = nuke.getInput('select child nodes labeled:','')
    for n in nuke.allNodes('Dot'):
        if n.knob('child') and n.knob('label'). getValue() == childName:
            n.setSelected(True)



# Add backpack
toolbar = nuke.menu('Nodes')
backpackToolbar = toolbar.addMenu('backpack' , icon = 'backpack.png')

fileMenu = nuke.menu('Nuke')
backpackMenu = fileMenu.addMenu('backpack')

#dDotParent
nuke.menu( 'Nodes' ).addCommand("Ugo/dDot/dDotParent (shift+.)", "dDotParent()", "shift+p")
#backpackMenu.addCommand("Ugo/dDot/dDotParent", "dDotParent()", "shift+.")

#dDotConnect
nuke.menu( 'Nodes' ).addCommand("Ugo/dDot/dDotConnect (ctrl+.)", "dDotConnect()",  "alt+shift+a")
#backpackMenu.addCommand("Ugo/dDot/dDotConnect", "dDotConnect()", "ctrl+.")

#dDotConnectSelected
nuke.menu( 'Nodes' ).addCommand("Ugo/dDot/dDotConnectSelected (ctrl+,)", "dDotConnectSelected()", "ctrl+,")
#backpackMenu.addCommand("Ugo/dDot/dDotConnectSelected", "dDotConnectSelected()", "ctrl+,")

#dDotCheckInput
nuke.menu( 'Nodes' ).addCommand("Ugo/dDot/dDotCheckInput (ctrl+shift+,)", "dDotCheckInput()", "ctrl+shift+,")
#backpackMenu.addCommand("Ugo/Dot/dDotCheckInput", "dDotCheckInput()", "ctrl+shift+,")

#dDotAutoConnect
nuke.menu( 'Nodes' ).addCommand("Ugo/dDot/dDotAutoConnect (ctrl+shift+.)", "dDotAutoConnect()", "alt+a")
#backpackMenu.addCommand("Ugo/dDot/dDotAutoConnect", "dDotAutoConnect()", "ctrl+shift+.")

#dDotShowChildren
nuke.menu( 'Nodes' ).addCommand("Ugo/dDot/dDotShowChildren (alt+,)", "dDotShowChildren()", "alt+,")
#backpackMenu.addCommand("Ugo/Dot/dDotShowChildren", "dDotShowChildren()", "alt+,")

#dDotToggleConnectionsVisibility
nuke.menu( 'Nodes' ).addCommand("Ugo/dDot/dDotToggleConnectionsVisibility (alt+.)", "dDotToggleConnectionsVisibility()", "alt+.")
#backpackMenu.addCommand("Ugo/dDot/dDotToggleConnectionsVisibility", "dDotToggleConnectionsVisibility()", "alt+.")

#dDotRollDownNameChange
nuke.menu( 'Nodes' ).addCommand("Ugo/dDot/dDotRollDownNameChange (alt+shift+,)", "dDotRollDownNameChange()","alt+shift+,")
#backpackMenu.addCommand("Ugo/dDot/dDotRollDownNameChange", "dDotRollDownNameChange()","alt+shift+,")

#dDotGrabParentName
nuke.menu( 'Nodes' ).addCommand("Ugo/dDot/dDotGrabParentName (alt+shift+.)", "dDotGrabParentName()","alt+shift+.")
#backpackMenu.addCommand("Ugo/dDot/dDotGrabParentName", "dDotGrabParentName()","alt+shift+.")

#dDotSelectChildren
nuke.menu( 'Nodes' ).addCommand("Ugo/dDot/dDotSelectChildren", "dDotSelectChildren()")
#backpackMenu.addCommand("Ugo/dDot/dDotSelectChildren", "dDotSelectChildren()")


##Hagbarth Tools
toolbar = nuke.toolbar("Nodes")
m = toolbar.addMenu("Hagbarth Tools", icon="h_tools.png")
m.addCommand("Silk", "nuke.createNode(\"h_silk\")", icon="h_silk.png")
m.addCommand("GradientEditor", "nuke.createNode(\"h_gradienteditor\")", icon="h_gradienteditor.png")

import ColorGradientUi

import nuke

toolbar = nuke.toolbar("Nodes")
m = toolbar.addMenu("MatteHue", icon="MatteHue.png")
m.addCommand("Cell Noise", "nuke.createNode('Cell_Noise.gizmo')", icon="Cell_Noise.png")

# See maxvanleeuwen.com/pixelsort for examples, updates, and more information!


# make gizmo item in menu
import nuke
nuke.menu('Nodes').addCommand('Filter/PixelSort', "nuke.createNode('PixelSort.gizmo')", icon='PixelSort.png')

