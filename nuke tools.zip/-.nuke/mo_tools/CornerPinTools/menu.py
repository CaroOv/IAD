import nuke
n=nuke.menu('Nuke')
n.addMenu('Mo_Tools/CornerPinTools' , icon="m.png" )
