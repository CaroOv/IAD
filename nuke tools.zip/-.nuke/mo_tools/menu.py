import nuke
n=nuke.menu('Nuke')
n.addMenu('Mo_Tools' , icon = "m.png")

