nuke.pluginAddPath("./autoCorners")
nuke.pluginAddPath("./setCPRef")
