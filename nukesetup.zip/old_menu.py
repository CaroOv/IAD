




import concatenate2Dtransforms

import Locometry


import os

import nukescripts
    

nodesToolbar = nuke.toolbar('Nodes')


import TX_Ramp


##Hagbarth Tools
toolbar = nuke.toolbar("Nodes")
m = toolbar.addMenu("Hagbarth Tools", icon="h_tools.png")
m.addCommand("Silk", "nuke.createNode(\"h_silk\")", icon="h_silk.png")
m.addCommand("GradientEditor", "nuke.createNode(\"h_gradienteditor\")", icon="h_gradienteditor.png")



import nuke

toolbar = nuke.toolbar("Nodes")
m = toolbar.addMenu("MatteHue", icon="MatteHue.png")
m.addCommand("Cell Noise", "nuke.createNode('Cell_Noise.gizmo')", icon="Cell_Noise.png")

# See maxvanleeuwen.com/pixelsort for examples, updates, and more information!


# make gizmo item in menu
import nuke
nuke.menu('Nodes').addCommand('Filter/PixelSort', "nuke.createNode('PixelSort.gizmo')", icon='PixelSort.png')

import nuke
###### DEFAULT #######

###
# custom shortcuts

nuke.menu('Nodes').addCommand('Other/PostageStamp', lambda: nuke.createNode('PostageStamp'), 'F3')
nuke.menu('Nodes').addCommand('Other/Invert', lambda: nuke.createNode('Invert'), 'ctrl+i')

# set default parameters
nuke.knobDefault("preferences.goofy_foot", "false")
nuke.knobDefault("Shuffle.label", "[value in1]")
nuke.knobDefault("Blur.label", "[value size]")
nuke.knobDefault("Blur.channels", "rgba")
nuke.knobDefault("Defocus.channels", "rgba")
nuke.knobDefault("Defocus.label", "[value defocus]")
nuke.knobDefault("Invert.channels", "rgba")
nuke.knobDefault("Multiply.channels", "rgba")


# set default parameters Rotopaint
nuke.knobDefault('RotoPaint.toolbox','brush')
nuke.knobDefault("RotoPaint.toolbox", '''brush {

{ brush opc 0.2 bs 20 h 0.8 ds 1 }

}''')


#nuke.knobDefault("Merge2.bbox", "B")
nuke.knobDefault("Merge2.label", '[expr [value mix]==1?"":"[value mix]"]')
nuke.knobDefault("Grade.label", '[expr [value mix]==1?"":"[value mix]"]')
nuke.knobDefault("ColorCorrect.label", '[expr [value mix]==1?"":"[value mix]"]')
nuke.knobDefault("ChannelMerge.label", '[expr [value mix]==1?"":"[value mix]"]')
nuke.knobDefault("Remove.operation", "keep")
nuke.knobDefault("Remove.channels", "rgba")
nuke.knobDefault("Remove.label", '[value channels]')
nuke.knobDefault("Tracker.label", '[value transform]\n F[value reference_frame]')
nuke.knobDefault("TimeOffset.label", "[value time_offset]")
nuke.knobDefault("ScanlineRender.ztest_enabled", '0')
nuke.knobDefault("ScanlineRender.MB_channel", "1")
nuke.knobDefault("Switch.label", "[value which]")
nuke.knobDefault("Dissolve.label", "[value which]")
nuke.knobDefault("Dissolve.channels", "rgba")
nuke.knobDefault("Exposure.mode", "Stops")
nuke.knobDefault("Exposure.label", "[value mode]")
nuke.knobDefault("LayerContactSheet.showLayerNames", "1")
nuke.knobDefault("Viewer.hide_input", "true")

# load my Gizmos
#nuke.menu( 'Nodes' ).addCommand( 'Other/', lambda: nuke.createNode( '' ) )

### Edit the label of a node ###

def editLabel():
    label = nuke.getInput('Label')
    
    for i in nuke.selectedNodes():
        i.knob('label').setValue(label)

nuke.menu('Nodes').addCommand('Custom Shortcuts/Edit Label', lambda: editLabel(), '&')

import nuke
### edit folder path here ###
DVPath = "./Deep2VP/"

### MJTLab - Deep2VP v4.0 ###
DVPFam = {"general" : ["Deep2VP","DVPToImage","DVPortal","DVPColorCorrect"] , 
		"matte" : ["DVPmatte","DVPattern","DVProjection"] , 
		"lighting" : ["DVPsetLight","DVPscene","DVPrelight","DVPrelightPT","DVPfresnel"] , 
		"shader" : ["DVP_Shader","DVP_ToonShader"]
		}
### hard code. Don't change it ###
toolbar = nuke.toolbar("Nodes")
DVP = toolbar.addMenu("Deep2VP", icon="Deep2VP.png")
for key,value in DVPFam.items() :
	for item in value :
		if key == "general" :
			DVP.addCommand( "{0}".format(item), "nuke.nodePaste(\"{0}{1}.nk\")".format(DVPath,item), icon="{0}.png".format(item) )
		else :
			DVP.addCommand( "{0}/{1}".format(key,item), "nuke.nodePaste(\"{0}{1}/{2}.nk\")".format(DVPath,key,item), icon="{0}.png".format(item) )
### end here ###