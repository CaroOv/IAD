# Copyright (c) 2009 The Foundry Visionmongers Ltd.  All Rights Reserved.

## init.py
## loaded by nuke before menu.py

nuke.pluginAddPath('./gizmos')
nuke.pluginAddPath('./icons')

nuke.pluginAddPath('./mo_tools')

import nukescripts
class createBackdrop (nukescripts.panels.PythonPanel):
    import re
    import os       
    #Create Panel
    def __init__( cbd ):
        global G_BDname
        global G_BDcolor
        G_BDname = ''
        G_BDcolor = 1044266751
        nukescripts.PythonPanel.__init__( cbd, 'Create Backdrop', 'cbackdrop')  
        
        cbd.bdname = nuke.String_Knob('bdname', 'name')
        cbd.tile = nuke.ColorChip_Knob('bdcolor','color', G_BDcolor)
        cbd.preset = nuke.Enumeration_Knob('bdpreset', 'preset' ,['', 'stage1','stage2', 'stage3', 'b1', 'b2', 'b3'])

        cbd.addKnob(cbd.preset)  
        cbd.addKnob(cbd.bdname)
        cbd.addKnob(cbd.tile)       

    def knobChanged(cbd, knob):
        global G_BDname
        global G_BDcolor
        if knob.name() == 'bdname':
            G_BDname =   cbd.bdname.getValue()
        if knob.name() == 'bdcolor':  
            G_BDcolor = int(cbd.tile.getValue())
            print G_BDcolor

        if knob.name() == 'bdpreset':
	  
	    if cbd.preset.value() == 'stage1':
                G_BDname = ''
                G_BDcolor = 1044266751
                cbd.bdname.setValue(G_BDname)
                cbd.tile.setValue(G_BDcolor)
	  
	  
	  
            if cbd.preset.value() == 'stage2':
                G_BDname = ''
                G_BDcolor = 2039056895
                cbd.bdname.setValue(G_BDname)
                cbd.tile.setValue(G_BDcolor)

            if cbd.preset.value() == 'stage3':
                G_BDname = ''
                G_BDcolor = 404495615
                cbd.bdname.setValue(G_BDname)
                cbd.tile.setValue(G_BDcolor)

            if cbd.preset.value() == 'b1':
                G_BDname = ''
                G_BDcolor = 1434451967
                cbd.bdname.setValue(G_BDname)
                cbd.tile.setValue(G_BDcolor)

            if cbd.preset.value() == 'b2':
                G_BDname = ''
                G_BDcolor = 10485759
                cbd.bdname.setValue(G_BDname)
                cbd.tile.setValue(G_BDcolor)

            if cbd.preset.value() == 'b3':
                G_BDname = ''
                G_BDcolor = 1442824191
                cbd.bdname.setValue(G_BDname)
                cbd.tile.setValue(G_BDcolor)
                

def createBackDropPanel():
    import os
    global G_BDname
    global G_BDcolor


    cBDd = createBackdrop().showModalDialog()
    if cBDd == True: 
        
        selNodes = nuke.selectedNodes()
        if not selNodes:
            bdrop = nuke.createNode('BackdropNode')
            bdrop['label'].setValue("<center><b>"+ G_BDname)
            bdrop['tile_color'].setValue(G_BDcolor)
            bdrop['note_font'].setValue("DejaVu Sans")
            bdrop['note_font_size'].setValue(40) 
	    bdrop['note_font_color'].setValue(255) 
            
        
        else:
            pX = min([node.xpos() for node in selNodes])
            pY = min([node.ypos() for node in selNodes])
            pW = max([node.xpos() + node.screenWidth() for node in selNodes]) - pX
            pH = max([node.ypos() + node.screenHeight() for node in selNodes]) - pY
            
            left, top, right, bottom = (-15, -85, 15, 15)
            pX += left
            pY += top
            pW += (right - left)
            pH += (bottom - top)
            
            bdrop = nuke.nodes.BackdropNode(xpos = pX,
            bdwidth = pW,
            ypos = pY,
            bdheight = pH,
            label = G_BDname,
            tile_color = G_BDcolor,
            note_font_size = 40)
            
            
            # create the Update Read node button
            nukescripts.clear_selection_recursive()
            bd = bdrop['selected'].setValue(1)
            sel= bdContents()
            found = 0
            for s in sel :   
                if s.Class() == 'Read' :
                    found = 1
                    
                    tabName = nuke.Tab_Knob("Update", "Update")
                    bdrop.addKnob(tabName)
                    scriptButton = nuke.PyScript_Knob("updateRead", "update all read nodes")
                    bdrop.addKnob(scriptButton)
                    scriptButton.setCommand("""updateBDreads()""") 
                    break
    else:
        print "let's not make a backdrop..they suck anyway"

##Hagbarth Tools
nuke.pluginAddPath('./hagbarth')
nuke.pluginAddPath('./hagbarth/icons')
nuke.pluginAddPath('./hagbarth/tools')
nuke.pluginAddPath('./hagbarth/grapichs')
nuke.pluginAddPath('./hagbarth/python')

# See maxvanleeuwen.com/pixelsort for examples, updates, and more information!

# This script will automatically load the right OS and Nuke version of the PixelSortCore plugin.
# If you have compiled your own version of it, simply adding it to a (new) folder with the right Nuke version name will work!


# never block Nuke starting
try:

	# get operating sys
	ops = ''

	import platform
	if platform.system() == "Windows": # Windows
		ops = 'Windows'
	elif platform.system() == "Darwin": # Mac OS
		ops = 'MacOS'
	else: # Linux
		ops = 'Linux'


	# get nuke version
	import nuke
	ver = nuke.NUKE_VERSION_STRING
	ver = ver.split('v')[-2]


	# get path to current directory
	cd = os.path.dirname(os.path.realpath(__file__)).replace("\\", "/")


	# path to current PixelSortCore library
	p = cd + '/PixelSortCore/' + ops + '/' + ver


	# check if PixelSortCore dir exists
	import os.path
	if os.path.isdir(p):
		# add it to plugin paths so the shared library will be loaded
		nuke.pluginAddPath(p)

except Exception as e:
	print('PixelSort failed to load. Error:\n' + str(e))



